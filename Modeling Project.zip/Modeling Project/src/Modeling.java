import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class Modeling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] weighted = { 382745, 799601, 909247, 729069, 467902, 44328, 34610, 698150, 823460, 903959, 853665, 551830,
				610856, 670702, 488960, 951111, 323046, 446298, 931161, 31385, 496951, 264724, 224916, 169684 };

		int[] profit = { 825594, 1677009, 1676628, 1523970, 943972, 97426, 69666, 1296457, 1679693, 1902996, 1844992,
				1049289, 1252836, 1319836, 953277, 2067538, 675367, 853655, 1826027, 65731, 901489, 577243, 466257,
				369261 };
		double knapsack_capacity = 6404180;

		ArrayList<node> pList = new ArrayList<node>();
		ArrayList<node> initialSolution = new ArrayList<node>();

		node[] nodeList = new node[24];
		node[] initialList = new node[24];

		for (int i = 0; i < profit.length; i++) { // Her node teker teker array elemanlarını ekliyor

			double k = profit[i];
			double l = weighted[i];
			nodeList[i] = new node(i, k, l);
			initialList[i] = new node(i, k, l);

		}

		for (int i = 0; i < nodeList.length; i++) { // Arrayliste nodeları atıyor
			pList.add(nodeList[i]);
			initialSolution.add(initialList[i]);
		}

		Collections.sort(pList); // Arraylist içindeki nodeları ratio göre sort ediyor
		Collections.sort(initialSolution);

		double weightPlist = 0;
		double weightInitialSolution = 0;
		double profitPlist = 0;
		double profitInitialSolution = 0;

		for (node p : pList) { // Find a Initial Solution

			if (p.weight <= knapsack_capacity - weightPlist) {
				weightPlist = weightPlist + p.weight;
				profitPlist = profitPlist + p.profit;
				p.setContains(1);
			}
		}

		for (node p : initialSolution) { // Find a Initial Solution
			if (p.weight <= knapsack_capacity - weightInitialSolution) {
				weightInitialSolution = weightInitialSolution + p.weight;
				profitInitialSolution = profitInitialSolution + p.profit;
				p.setContains(1);
			}
		}

		Random random = new Random(); // random generate number
		int tempRandomNumber = random.nextInt(pList.size());
	//	System.out.println("İlk Random Numara " + tempRandomNumber);
	//	System.out.println(pList.get(tempRandomNumber).contains);

		while (initialSolution.get(tempRandomNumber).contains == 1) {

			Random randomNumber2 = new Random(); // random generate number
			int tempRandomNumber2 = randomNumber2.nextInt(initialSolution.size());
			tempRandomNumber = tempRandomNumber2;
		} // Garanti olarak index kesin 0 olacağı belli oluyor.

		
		pList.get(tempRandomNumber).contains = 1;
		
		while(weightPlist + pList.get(tempRandomNumber).weight <= knapsack_capacity && profitPlist >= profitInitialSolution) {
			weightPlist = weightPlist + pList.get(tempRandomNumber).weight;
			profitPlist = profitPlist + pList.get(tempRandomNumber).profit;
			
			if(profitPlist > profitInitialSolution) {
				//random atıcak
			}else {
				
			}
				
			
		}
		

		if (initialSolution.get(tempRandomNumber).contains == 0) {
			

			
			
			
				
				while(profitPlist > profitInitialSolution) {
					//random yarat
				}
				
			}else {
				//random 1 çıkar
				//kapasite kontrol et
				//if sağlarsa profite bak büyükse random yarat
				//değilse algortimaya gir
				
			}
				

		


	}

}
